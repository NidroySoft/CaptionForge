using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Diagnostics;
using CaptionForge.Application.Abstractions;
using CaptionForge.Application.Enums;
using CaptionForge.Application.Exceptions;
using CaptionForge.Application.Models.Generation;
using CaptionForge.Application.Models.Media;
using CaptionForge.Application.Models.Settings;
using CaptionForge.Application.Models.Workspace;
using CaptionForge.Application.Models.Writing;
using CaptionForge.Application.Services;
using CaptionForge.Core.Models.Subtitles;
using CaptionForge.Core.Models.Transcription;
using CaptionForge.Core.Models.Media;
using CaptionForge.Core.ValueObjects;
using CaptionForge.Infrastructure.CapCut;
using CaptionForge.Infrastructure.Configuration;
using CaptionForge.Infrastructure.Media;
using CaptionForge.Infrastructure.Settings;
using CaptionForge.Infrastructure.Transcription;
using CaptionForge.Infrastructure.Workspace;
using Whisper.net;

string fixturePath=Path.GetFullPath(args[0]);string reportPath=Path.GetFullPath(args[1]);
var tests=new Checks();var work=Path.Combine(Path.GetTempPath(),"CaptionForge.Infrastructure.Verification",Guid.NewGuid().ToString("N"));Directory.CreateDirectory(work);
var sessions=new List<Session>();
async Task<Session> SessionAsync(string fixture="snapshot_audio_only.json",string? rootFixture=null)
{ var s=await Session.CreateAsync(work,fixturePath,fixture,rootFixture);sessions.Add(s);return s; }

var normal=await SessionAsync();
tests.Check(normal.Project.Id=="2A30AAE9-2228-48ab-BA00-AF0598C88C3B", "Catálogo: draft_id real del proyecto");
tests.Check(normal.Project.TimelineRegistryId=="3A81E819-70C3-4b5c-8DB8-4D07897271C9", "Catálogo: ID de registro distinto");
tests.Check(normal.Snapshot.Timeline.Id=="EFA8ACC8-F181-4059-96C5-6BC82353A0C6" && normal.Snapshot.Timeline.IsMain,"Catálogo: timeline real y main");
tests.Check(normal.Snapshot.Timeline.FrameRate==new FrameRate(30) && normal.Snapshot.Timeline.DurationUs==36_533_333,"FPS y duración reales");
tests.Check(normal.Snapshot.Tracks.Count==2 && normal.Snapshot.Tracks[1].Segments.Count==1,"Pistas existentes, vídeo vacío y audio");
tests.Check(normal.Snapshot.Tracks[1].Segments[0].MaterialId=="46EA7246-9A61-4611-951E-B2E93F0715ED","material_id resuelve audio");
tests.Check(normal.Catalog.LastWarnings.Any(x=>x.Contains("medio ausente",StringComparison.Ordinal)),"Ruta ausente conservada con diagnóstico");
tests.Check(normal.Snapshot.SourceFiles.Count==6 && normal.Snapshot.SourceFiles.Any(f=>!f.Exists && f.Path.EndsWith(".bak",StringComparison.Ordinal)),"Captura incluye .bak ausentes y metadata/registro");
tests.Check(normal.Project.CoverPath is not null && normal.Snapshot.Timeline.CoverPath is not null,"Covers en catálogo");

using var expected=JsonDocument.Parse(File.ReadAllText(Path.Combine(fixturePath,"expected_captions_v3.json")));
var initialBytes=normal.Files.ToDictionary(p=>p,p=>File.Exists(p)?File.ReadAllBytes(p):null);
var result=await normal.GenerateAsync();
tests.Check(normal.Status()=="ReadyToApply" && normal.Files.All(p=>EqualBytes(p,initialBytes[p])),"Preparar no modifica CapCut");
tests.Check(File.Exists(Path.Combine(result.Run.RunDirectory,"result","generation.json")) && File.Exists(Path.Combine(result.Run.RunDirectory,"result","subtitles.srt")),"Generación y SRT propios persistidos");
tests.Check(result.Plan.ExpectedFiles.Count==4,"Espejo raíz coincidente incluye cuatro archivos");
tests.Check(result.Plan.ManagedSubtitles.Objects.Count==91,"Grafo v3: una pista y 6 identidades por cada uno de 15 captions");
tests.Check(result.Captions.Count==15,"15 captions mediante Application e Infrastructure");
for (int i=0;i<15;i++)
{
 var cue=result.Captions[i];var exp=expected.RootElement[i];var range=exp.GetProperty("range");
 tests.Check(cue.TimelineRange.StartUs==range.GetProperty("start").GetInt64() && cue.TimelineRange.DurationUs==range.GetProperty("duration").GetInt64(),$"Golden {i+1}: rango exacto");
 tests.Check(cue.Text==exp.GetProperty("text").GetString(),$"Golden {i+1}: texto editorial del fixture");
 var words=exp.GetProperty("words");
 tests.Check(cue.Words.Select(x=>x.Text).SequenceEqual(words.GetProperty("text").EnumerateArray().Select(x=>x.GetString())) &&
  cue.Words.Select(x=>x.StartTimeMs).SequenceEqual(words.GetProperty("start_time").EnumerateArray().Select(x=>x.GetInt64())) &&
  cue.Words.Select(x=>x.EndTimeMs).SequenceEqual(words.GetProperty("end_time").EnumerateArray().Select(x=>x.GetInt64())),$"Golden {i+1}: arrays words exactos desde normalizador Whisper.net");
}
var receipt=await normal.Service.ApplyAsync(result);
tests.Check(normal.Status()=="Completed" && receipt.Files.Count==4,"Commit real sobre cuatro archivos de copia");
tests.Check(File.ReadAllBytes(normal.Draft).SequenceEqual(File.ReadAllBytes(normal.Draft+".bak")) && File.ReadAllBytes(normal.RootDraft).SequenceEqual(File.ReadAllBytes(normal.RootDraft+".bak")),".bak nativos sincronizados al JSON nuevo");
tests.Check(File.ReadAllBytes(normal.RootDraft).SequenceEqual(File.ReadAllBytes(normal.Draft)),"Espejo sincronizado a la timeline correspondiente");
tests.Check(receipt.Files.Where(f=>f.Before.Exists).All(f=>File.ReadAllBytes(f.BackupPath!).SequenceEqual(initialBytes[f.Before.Path]!)),"Backup byte a byte del estado inmediatamente anterior");
var patched=Read(normal.Draft);var original=Read(Path.Combine(fixturePath,"snapshot_audio_only.json"));
tests.Check(patched["id"]!.GetValue<string>()==original["id"]!.GetValue<string>(),"ID original conservado, sin identidad del golden extranjero");
foreach (var pair in original)
 if (pair.Key is not ("tracks" or "materials")) tests.Check(JsonNode.DeepEquals(pair.Value,patched[pair.Key]),"Preserva propiedad raíz: "+pair.Key);
var originalTracks=original["tracks"]!.AsArray();var newTracks=patched["tracks"]!.AsArray();
tests.Check(originalTracks.All(t=>newTracks.Any(n=>JsonNode.DeepEquals(t,n))),"Pistas originales sin cambios");
foreach (var pair in original["materials"]!.AsObject())
{
 var old=pair.Value!.AsArray();var current=patched["materials"]![pair.Key]!.AsArray();
 tests.Check(old.All(o=>current.Any(n=>JsonNode.DeepEquals(o,n))),"Preserva materiales originales: "+pair.Key);
}
ValidateGraph(patched,result,tests);
var managed=await normal.Store.ReadManagedSubtitlesAsync(normal.Project.Id,normal.Snapshot.Timeline.Id);
tests.Check(managed!.Objects.SequenceEqual(result.Plan.ManagedSubtitles.Objects),"Registro de identidades persiste tras commit");
tests.Check(Read(receipt.JournalPath)["phase"]!.GetValue<string>()=="Committed","Journal durable confirmado");
await tests.ErrorAsync(()=>normal.Service.ApplyAsync(result),OperationErrorCode.RunStateConflict,"No reaplica ejecución completada");
await normal.Writer.RestoreAsync(receipt.JournalPath);
tests.Check(normal.Files.All(p=>EqualBytes(p,initialBytes[p])),"Restauración exacta: originales anteriores y eliminación de .bak nuevos");
tests.Check(await normal.Store.ReadManagedSubtitlesAsync(normal.Project.Id,normal.Snapshot.Timeline.Id) is null,"Restaurar primera ejecución elimina su registro propio");
tests.Check(Read(receipt.JournalPath)["phase"]!.GetValue<string>()=="Restored" && Read(Path.Combine(result.Run.RunDirectory,"run.json"))["restoration"] is not null,"Restauración registrada sin fingir ejecución nueva");

var foreign=await SessionAsync("snapshot_with_manual_template.json","root_draft_content.json");
var beforeForeign=Read(foreign.Draft);var foreignIds=beforeForeign["tracks"]!.AsArray().Select(t=>t!["id"]!.GetValue<string>()).ToArray();
var foreignResult=await foreign.GenerateAsync();var foreignReceipt=await foreign.Service.ApplyAsync(foreignResult);
var afterForeign=Read(foreign.Draft);
tests.Check(foreignResult.Plan.Warnings.Any(x=>x.Contains("ajenos",StringComparison.Ordinal)),"Advierte duplicación visual por captions ajenos");
tests.Check(beforeForeign["tracks"]!.AsArray().All(t=>afterForeign["tracks"]!.AsArray().Any(n=>JsonNode.DeepEquals(t,n))),"SRT y plantilla manual ajenos preservados completos");
tests.Check(foreignResult.Plan.ExpectedFiles.Count==4,"Espejo admite la diferencia numérica mínima del fixture real");
var withUnknowns=Read(foreign.Draft);string firstOwnTextId=foreignResult.Plan.ManagedSubtitles.Objects.First(o=>o.Kind==SubtitleObjectKind.Text).Id;
var ownText=withUnknowns["materials"]!["texts"]!.AsArray().Single(t=>t!["id"]!.GetValue<string>()==firstOwnTextId)!;
ownText["future_field"]=new JsonObject {["retain"]=true};var ownContent=JsonNode.Parse(ownText["content"]!.GetValue<string>())!;ownContent["future_content_field"]="retain";ownText["content"]=ownContent.ToJsonString();
Write(foreign.Draft,withUnknowns);Write(foreign.RootDraft,withUnknowns);
var firstAppliedBytes=foreign.Files.ToDictionary(p=>p,p=>File.ReadAllBytes(p));

// Una segunda ejecución usa el registro real y conserva los IDs propios al regenerar.
var firstManaged=foreignResult.Plan.ManagedSubtitles.Objects.ToArray();
foreign.Snapshot=await foreign.Catalog.ReadTimelineAsync(foreign.Project,foreign.Snapshot.Timeline);foreign.Transcriber.ChangeFirstWord=true;
var second=await foreign.GenerateAsync();await foreign.Service.ApplyAsync(second);
tests.Check(second.Run.RunId!=foreignResult.Run.RunId && second.Run.ProjectDirectory==foreignResult.Run.ProjectDirectory,"Carpeta de proyecto reutilizada, run único");
tests.Check(firstManaged.SequenceEqual(second.Plan.ManagedSubtitles.Objects),"Regeneración conserva todos los IDs administrados");
tests.Check(Read(foreign.Draft)["tracks"]!.AsArray().Count==beforeForeign["tracks"]!.AsArray().Count+1,"Regenerar no duplica la pista propia");
tests.Check(second.Captions[0].Text.StartsWith("That",StringComparison.Ordinal),"Actualización cambia texto conservando grafo");
var updatedText=Read(foreign.Draft)["materials"]!["texts"]!.AsArray().Single(t=>t!["id"]!.GetValue<string>()==firstOwnTextId)!;
tests.Check(updatedText["future_field"]?["retain"]?.GetValue<bool>()==true && JsonNode.Parse(updatedText["content"]!.GetValue<string>())?["future_content_field"]?.GetValue<string>()=="retain","Actualización conserva campos desconocidos en material propio y JSON content");
await tests.ErrorAsync(()=>foreign.Writer.RestoreAsync(foreignReceipt.JournalPath),OperationErrorCode.SourceChanged,"No restaura backup anterior sobre una ejecución posterior");
await foreign.Writer.RestoreAsync(Path.Combine(second.Run.RunDirectory,"journal.json"));
tests.Check(foreign.Files.All(p=>File.ReadAllBytes(p).SequenceEqual(firstAppliedBytes[p])),"Restauración segunda ejecución recupera exactamente sus cuatro estados anteriores");
tests.Check((await foreign.Store.ReadManagedSubtitlesAsync(foreign.Project.Id,foreign.Snapshot.Timeline.Id))!.Objects.SequenceEqual(firstManaged),"Restaurar actualización devuelve registro anterior");

var differentRoot=await SessionAsync();var rootOther=Read(differentRoot.RootDraft);rootOther["id"]="OTHER-TIMELINE";Write(differentRoot.RootDraft,rootOther);
differentRoot.Snapshot=await differentRoot.Catalog.ReadTimelineAsync(differentRoot.Project,differentRoot.Snapshot.Timeline);byte[] otherBytes=File.ReadAllBytes(differentRoot.RootDraft);
var otherPlan=await differentRoot.GenerateAsync();await differentRoot.Service.ApplyAsync(otherPlan);
tests.Check(otherPlan.Plan.ExpectedFiles.Count==2 && File.ReadAllBytes(differentRoot.RootDraft).SequenceEqual(otherBytes),"Raíz de otra timeline no se toca");

var existingBak=await SessionAsync();File.WriteAllBytes(existingBak.Draft+".bak",Encoding.UTF8.GetBytes("backup nativo anterior"));File.WriteAllBytes(existingBak.RootDraft+".bak",Encoding.UTF8.GetBytes("otro backup nativo anterior"));
existingBak.Snapshot=await existingBak.Catalog.ReadTimelineAsync(existingBak.Project,existingBak.Snapshot.Timeline);var bakBytes=existingBak.Files.ToDictionary(p=>p,p=>File.ReadAllBytes(p));
var bakRun=await existingBak.GenerateAsync();var bakReceipt=await existingBak.Service.ApplyAsync(bakRun);
tests.Check(bakReceipt.Files.All(f=>f.Before.Exists && File.ReadAllBytes(f.BackupPath!).SequenceEqual(bakBytes[f.Before.Path])),"Respaldos propios incluyen bytes de .bak nativos viejos");
await existingBak.Writer.RestoreAsync(bakReceipt.JournalPath);tests.Check(existingBak.Files.All(p=>File.ReadAllBytes(p).SequenceEqual(bakBytes[p])),"Restaurar también recupera los .bak nativos anteriores");

var stale=await SessionAsync();var staleReady=await stale.GenerateAsync();File.AppendAllText(stale.Draft," ");byte[] edited=File.ReadAllBytes(stale.Draft);
await tests.ErrorAsync(()=>stale.Service.ApplyAsync(staleReady),OperationErrorCode.SourceChanged,"Hashes detectan cambio previo a commit");
tests.Check(File.ReadAllBytes(stale.Draft).SequenceEqual(edited) && !File.Exists(stale.Draft+".bak"),"Rechazo de hash no escribe ni crea .bak");
var stalePlan=await SessionAsync();var stalePlanReady=await stalePlan.GenerateAsync();File.AppendAllText(stalePlanReady.Plan.PlanPath," ");
await tests.ErrorAsync(()=>stalePlan.Service.ApplyAsync(stalePlanReady),OperationErrorCode.SourceChanged,"Detecta modificación del plan durable");
var staged=await SessionAsync();var stagedReady=await staged.GenerateAsync();var stagedDoc=Read(stagedReady.Plan.PlanPath);File.AppendAllText(stagedDoc["files"]![0]!["stagedPath"]!.GetValue<string>()," ");
await tests.ErrorAsync(()=>staged.Service.ApplyAsync(stagedReady),OperationErrorCode.SourceChanged,"Detecta copia preparada alterada");
var changedRestore=await SessionAsync();var changedRun=await changedRestore.GenerateAsync();var changedReceipt=await changedRestore.Service.ApplyAsync(changedRun);File.AppendAllText(changedRestore.Draft," ");
await tests.ErrorAsync(()=>changedRestore.Writer.RestoreAsync(changedReceipt.JournalPath),OperationErrorCode.SourceChanged,"Restauración rechaza edición posterior");

var interrupted=await SessionAsync();var beforeInterrupted=interrupted.Files.ToDictionary(p=>p,p=>File.Exists(p)?File.ReadAllBytes(p):null);
interrupted.SetWriter(new GoldenV3SubtitleWriter(interrupted.Assets,new ClosedGuard(),new FailCommitter(2)));
var interruptedRun=await interrupted.GenerateAsync();await tests.ErrorAsync(()=>interrupted.Service.ApplyAsync(interruptedRun),OperationErrorCode.RecoveryRequired,"Fallo en segundo reemplazo exige revisar journal");
tests.Check(interrupted.Files.All(p=>EqualBytes(p,beforeInterrupted[p])),"Rollback recupera conjunto tras fallo parcial real");
tests.Check(Read(Path.Combine(interruptedRun.Run.RunDirectory,"journal.json"))["phase"]!.GetValue<string>()=="RolledBack","Journal identifica rollback exitoso");

var recovery=await SessionAsync();recovery.SetWriter(new GoldenV3SubtitleWriter(recovery.Assets,new ClosedGuard(),new BreakRollbackCommitter(recovery.Directory)));var recoveryRun=await recovery.GenerateAsync();
await tests.ErrorAsync(()=>recovery.Service.ApplyAsync(recoveryRun),OperationErrorCode.RecoveryRequired,"Fallo de commit y backup dañado conservan estado incierto");
tests.Check(Read(Path.Combine(recoveryRun.Run.RunDirectory,"journal.json"))["phase"]!.GetValue<string>()=="RecoveryRequired","Journal persiste fallo de rollback");

var open=await SessionAsync();open.SetWriter(new GoldenV3SubtitleWriter(open.Assets,new OpenGuard()));var openRun=await open.GenerateAsync();
await tests.ErrorAsync(()=>open.Service.ApplyAsync(openRun),OperationErrorCode.CapCutOpen,"CapCut abierto bloquea escritura");tests.Check(open.Status()=="ReadyToApply","CapCut abierto conserva plan revisable");
var invalidMirror=await SessionAsync();var badMirror=Read(invalidMirror.RootDraft);badMirror["duration"]=999;Write(invalidMirror.RootDraft,badMirror);
invalidMirror.Snapshot=await invalidMirror.Catalog.ReadTimelineAsync(invalidMirror.Project,invalidMirror.Snapshot.Timeline);
await tests.ErrorAsync(()=>invalidMirror.GenerateAsync(),OperationErrorCode.SourceChanged,"Mismo ID con raíz discordante no se copia ciegamente");
var missingAssets=await SessionAsync();File.Delete(missingAssets.Assets.FontFile);
await tests.ErrorAsync(()=>missingAssets.GenerateAsync(),OperationErrorCode.ResourceUnavailable,"Fuente ausente no produce plan supuestamente válido");

var settingsStore=new JsonApplicationSettingsStore(Path.Combine(work,"settings","settings.json"));tests.Check((await settingsStore.LoadAsync()).Language=="auto","Ajustes por defecto si no existe archivo");
var settings=new ApplicationSettings("projects","workspace","model","es",4);await settingsStore.SaveAsync(settings);tests.Check(await settingsStore.LoadAsync()==settings,"Ajustes persistidos y leídos con ctor validado");
var catalogRoot=Path.Combine(work,"invalid-projects");Directory.CreateDirectory(Path.Combine(catalogRoot,"broken"));File.WriteAllText(Path.Combine(catalogRoot,"broken","draft_meta_info.json"),"broken");
var badCatalog=new CapCutCatalog();tests.Check((await badCatalog.FindProjectsAsync(catalogRoot)).Count==0 && badCatalog.LastWarnings.Count==1,"Proyecto corrupto diagnosticado sin inventarlo");
await tests.ThrowsAsync<DirectoryNotFoundException>(()=>badCatalog.FindProjectsAsync(Path.Combine(work,"missing")),"Raíz inexistente requiere ruta alternativa");
var future=await SessionAsync();var futureDoc=Read(future.Draft);futureDoc["version"]=400000;Write(future.Draft,futureDoc);
tests.Check((await future.Catalog.GetTimelinesAsync(future.Project)).Count==0 && future.Catalog.LastWarnings.Any(w=>w.Contains("esquema",StringComparison.Ordinal)),"Formato futuro no se interpreta ni modifica como si estuviera verificado");
var duplicate=await SessionAsync();string secondFolder=Path.Combine(Path.GetDirectoryName(duplicate.Project.DirectoryPath)!,"duplicate");Directory.CreateDirectory(Path.Combine(secondFolder,"Timelines",duplicate.Snapshot.Timeline.Id));
File.Copy(Path.Combine(duplicate.Project.DirectoryPath,"draft_meta_info.json"),Path.Combine(secondFolder,"draft_meta_info.json"));File.Copy(Path.Combine(duplicate.Project.DirectoryPath,"Timelines","project.json"),Path.Combine(secondFolder,"Timelines","project.json"));File.Copy(duplicate.Draft,Path.Combine(secondFolder,"Timelines",duplicate.Snapshot.Timeline.Id,"draft_content.json"));
tests.Check((await duplicate.Catalog.FindProjectsAsync(Path.GetDirectoryName(duplicate.Project.DirectoryPath)!)).Count==0 && duplicate.Catalog.LastWarnings.Any(w=>w.Contains("varias carpetas",StringComparison.Ordinal)),"IDs duplicados de proyecto no comparten silenciosamente el espacio propio");
var illegal=await SessionAsync();var created=await illegal.Store.CreateRunAsync(illegal.Request());
await tests.ErrorAsync(()=>illegal.Store.TransitionAsync(created,new(RunStatus.Created,RunStatus.Applying,DateTimeOffset.UtcNow)),OperationErrorCode.RunStateConflict,"Manifiesto rechaza transición ilegal");
using var cancelled=new CancellationTokenSource();cancelled.Cancel();await tests.ThrowsAsync<OperationCanceledException>(()=>illegal.Store.TransitionAsync(created,new(RunStatus.Created,RunStatus.PreparingAudio,DateTimeOffset.UtcNow),cancelled.Token),"Estado no cambia con cancelación previa");
tests.Check(Read(Path.Combine(created.RunDirectory,"run.json"))["status"]!.GetValue<string>()=="Created","Transición cancelada conserva estado anterior");

// Commit de una ejecución y finalización tardía mientras otra ya termina: no pisa el registro posterior.
var race=await SessionAsync();var delayed=new DelayedCompletionStore(race.Store);
var delayedService=new CaptionGenerationService(new FixtureAudio(),race.Transcriber,race.Writer,delayed);
var slowResult=await delayedService.GenerateAsync(race.Request());var slowApply=delayedService.ApplyAsync(slowResult);await delayed.Entered.Task;
tests.Check((await race.Store.ReadManagedSubtitlesAsync(race.Project.Id,race.Snapshot.Timeline.Id)) is not null,"El escritor publica IDs antes de finalizar manifiesto");
race.Snapshot=await race.Catalog.ReadTimelineAsync(race.Project,race.Snapshot.Timeline);var fastResult=await race.GenerateAsync();await race.Service.ApplyAsync(fastResult);
delayed.Release.SetResult();await slowApply;
var latestRegistry=Read(Path.Combine(fastResult.Run.ProjectDirectory,"managed",fastResult.Run.TimelineId+".json"));
tests.Check(latestRegistry["runId"]!.GetValue<string>()==fastResult.Run.RunId,"Finalización tardía no sobrescribe el registro de la ejecución posterior");
tests.Check(Read(Path.Combine(slowResult.Run.RunDirectory,"run.json"))["status"]!.GetValue<string>()=="Completed","Ejecución anterior confirma su recibo sin revertir la posterior");

// Los tiempos de la API nativa son unidades de 10 ms, independientemente del timestamp DTW diagnóstico.
var nativeSegment=new SegmentData(" Hello",TimeSpan.Zero,TimeSpan.FromSeconds(1),0,0,0,0,"en",new[] { new WhisperToken {Id=770,Text=" Hello",Start=20,End=60,DtwTimestamp=999999},new WhisperToken {Id=50256,Text="<|endoftext|>",Start=-1,End=-1} });
var normalized=WhisperTokenNormalizer.Normalize(nativeSegment,true);
tests.Check(normalized.Tokens[0].Range==new TimeRangeUs(200_000,400_000) && normalized.Tokens[1].IsControl,"Normaliza 10ms→µs y separa controles; no interpreta t_dtw");
tests.Throws<InvalidDataException>(()=>WhisperTokenNormalizer.Normalize(new SegmentData("bad",TimeSpan.Zero,TimeSpan.FromSeconds(1),0,0,0,0,"en",new[] {new WhisperToken {Id=1,Text=" bad",Start=-1,End=0}}),true),"Token sin offset no recibe tiempo inventado");

// Audio real con FFmpeg: recorte, padding pequeño, vídeo con audio y vídeo sin audio.
string source=Path.Combine(work,"source with spaces.wav");WriteWave(source,32_000,880);
var audioSession=await SessionAsync();var audioRun=await audioSession.Store.CreateRunAsync(audioSession.Request());
var audioService=new FfmpegAudioPreparationService();
var audioSegment=new MediaSegment("audio-slice","track","material",source,new(1_000_000,500_000),new(10_000_000,500_000));
var prepared=await audioService.PrepareAsync(new(audioRun,audioSegment,source));var info=PcmWaveInfo.Read(prepared.Path);
tests.Check(info.SampleFrames==8000 && prepared.DurationUs==500_000 && prepared.MeasuredDurationUs==500_000,"FFmpeg real recorta a 8000 muestras mono16k");
tests.Check(File.Exists(Path.ChangeExtension(prepared.Path,null)+"-mapping.json"),"Mapa temporal de audio persistido");
var padding=new MediaSegment("padding","track","material",source,new(0,2_008_333),new(0,2_008_333));var padded=await audioService.PrepareAsync(new(audioRun,padding,source));
tests.Check(Math.Abs(padded.MeasuredDurationUs-padded.DurationUs)<=63,"FFmpeg resuelve pequeño desfase con padding/rejilla de muestras");
var video=Path.Combine(work,"video with audio.mp4");await RunFfmpegAsync(new[] {"-f","lavfi","-i","color=c=black:s=64x64:r=25:d=2","-i",source,"-shortest","-c:v","mpeg4","-c:a","aac","-y",video});
var videoSegment=new MediaSegment("video-slice","track","material",video,new(500_000,1_000_000),new(0,1_000_000));var videoAudio=await audioService.PrepareAsync(new(audioRun,videoSegment,video));
tests.Check(PcmWaveInfo.Read(videoAudio.Path).SampleFrames==16000,"FFmpeg extrae audio de vídeo y respeta recorte");
var silentVideo=Path.Combine(work,"silent.mp4");await RunFfmpegAsync(new[] {"-f","lavfi","-i","color=c=black:s=64x64:r=25:d=1","-an","-c:v","mpeg4","-y",silentVideo});
await tests.ErrorAsync(()=>audioService.PrepareAsync(new(audioRun,new MediaSegment("silent","t","m",silentVideo,new(0,1_000_000),new(0,1_000_000)),silentVideo)),OperationErrorCode.UnsupportedMedia,"Vídeo sin audio diagnosticado");
using var cancelAudio=new CancellationTokenSource();cancelAudio.Cancel();await tests.ThrowsAsync<OperationCanceledException>(()=>audioService.PrepareAsync(new(audioRun,audioSegment,source),cancelAudio.Token),"Cancelación de preparación antes de ejecutar proceso");
await tests.ErrorAsync(()=>new FfmpegAudioPreparationService("missing-ffmpeg","missing-ffprobe").PrepareAsync(new(audioRun,audioSegment,source)),OperationErrorCode.ResourceUnavailable,"Ejecutables ausentes diagnosticados");

object nativeReport=new {executed=false,reason="Opcional: suministra modelo GGML y muestra de voz en los argumentos 3 y 4."};
if (args.Length>=4)
{
 var nativeSession=await SessionAsync();var draft=Read(nativeSession.Draft);var seg=draft["tracks"]![1]!["segments"]![0]!;
 seg["source_timerange"]=new JsonObject {["start"]=0,["duration"]=11_000_000};seg["target_timerange"]=new JsonObject {["start"]=20_000_000,["duration"]=11_000_000};
 Write(nativeSession.Draft,draft);Write(nativeSession.RootDraft,draft);nativeSession.Snapshot=await nativeSession.Catalog.ReadTimelineAsync(nativeSession.Project,nativeSession.Snapshot.Timeline);
 await using var whisper=new WhisperNetTranscriptionService();var service=new CaptionGenerationService(audioService,whisper,nativeSession.Writer,nativeSession.Store);
 string sourceId=nativeSession.Snapshot.Tracks[1].Segments[0].Id;var options=new TranscriptionOptions("native-check",Path.GetFullPath(args[2]),"en",Math.Min(2,Environment.ProcessorCount),Environment.ProcessorCount);
 var req=new GenerateCaptionsRequest(nativeSession.Snapshot,new[] {sourceId},options,nativeSession.Store.RootDirectory,new[] {new SourcePathOverride(sourceId,Path.GetFullPath(args[3]))});
 var watch=Stopwatch.StartNew();var nativeResult=await service.GenerateAsync(req);watch.Stop();
 tests.Check(nativeResult.Captions.Count>0 && nativeResult.Transcriptions.Single().Segments.Count>0,"Whisper.net CPU+DTW real reconoce voz sin CLI");
 tests.Check(nativeResult.Captions.All(c=>c.TimelineRange.StartUs>=20_000_000 && c.TimelineRange.EndUs<=31_000_000),"Pipeline nativo traslada captions al destino 20s y los limita");
 var nativeReceipt=await service.ApplyAsync(nativeResult);tests.Check(nativeReceipt.Files.Count==4,"Pipeline completo nativo aplica JSON v3 a copias");
 string nativeWave=Directory.GetFiles(Path.Combine(nativeResult.Run.RunDirectory,"audio"),"*.wav").Single();
 var automatic=await whisper.TranscribeAsync(nativeResult.Run,new PreparedAudio(sourceId,nativeWave,11_000_000,PcmWaveInfo.Read(nativeWave).DurationUs),new TranscriptionOptions("native-check",Path.GetFullPath(args[2]),"auto",Math.Min(2,Environment.ProcessorCount),Environment.ProcessorCount));
 tests.Check(automatic.Language=="en" && automatic.Segments.Count>0,"Whisper.net real usa idioma inglés del modelo .en con auto y reutiliza la fábrica");
 nativeReport=new {executed=true,model=WhisperModelInfo.Read(args[2]).AlignmentPreset.ToString(),cpu=true,dtw=true,seconds=watch.Elapsed.TotalSeconds,captions=nativeResult.Captions.Count,text=string.Join(" ",nativeResult.Captions.Select(c=>c.Text)),capCutApplicationExecuted=false};
}

var report=new {status="passed",sdk="10.0.401",runtime=Environment.Version.ToString(),configuration="Release",checks=tests.Names.Count,names=tests.Names,
 reference=new {captions=15,wordArraysExact=15,fixtureOnlyEditorialCorrections=true},ffmpegReal=true,whisperNative=nativeReport,
 scope="Archivos/catálogo/escritor/persistencia reales en carpetas temporales. Assets visuales ficticios de prueba. Sin abrir CapCut ni WPF.",temporaryWorkDirectory=work};
File.WriteAllText(reportPath,JsonSerializer.Serialize(report,new JsonSerializerOptions {WriteIndented=true}));Console.WriteLine($"PASS {tests.Names.Count} checks; real FFmpeg; report: {reportPath}");

static bool EqualBytes(string path,byte[]? expected) => expected is null ? !File.Exists(path) : File.Exists(path) && File.ReadAllBytes(path).SequenceEqual(expected);
static JsonObject Read(string path) => JsonNode.Parse(File.ReadAllBytes(path))!.AsObject();
static void Write(string path,JsonNode node) => File.WriteAllText(path,node.ToJsonString(new JsonSerializerOptions {WriteIndented=true}));
static void ValidateGraph(JsonObject draft,GenerationResult result,Checks tests)
{
 var track=draft["tracks"]!.AsArray().Single(t=>t!["id"]!.GetValue<string>()==result.Plan.ManagedSubtitles.Objects.Single(o=>o.Kind==SubtitleObjectKind.Track).Id)!;
 var materials=draft["materials"]!;
 foreach (var s in track["segments"]!.AsArray())
 {
  var template=materials["text_templates"]!.AsArray().Single(t=>t!["id"]!.GetValue<string>()==s!["material_id"]!.GetValue<string>())!;var a=template["text_info_resources"]![0]!;
  var text=materials["texts"]!.AsArray().Single(t=>t!["id"]!.GetValue<string>()==a["text_material_id"]!.GetValue<string>())!;var content=JsonNode.Parse(text["content"]!.GetValue<string>())!;
  var animation=materials["material_animations"]!.AsArray().Single(t=>t!["id"]!.GetValue<string>()==s!["extra_material_refs"]![0]!.GetValue<string>())!;
  tests.Check(template["resource_id"]!.GetValue<string>()=="7535399757947161873" && content["styles"]![0]!["font"]!["id"]!.GetValue<string>()=="7517426090072149264","Grafo golden: plantilla/fuente definitivas");
  tests.Check(a["attach_info"]!["duration"]!.GetValue<long>()==s!["target_timerange"]!["duration"]!.GetValue<long>()-1 && animation["animations"]![0]!["duration"]!.GetValue<long>()==a["attach_info"]!["duration"]!.GetValue<long>(),"Grafo golden: duraciones D-1 de attachment/animación");
  tests.Check(a["extra_material_refs"]![0]!.GetValue<string>()==s!["extra_material_refs"]![1]!.GetValue<string>() && a["extra_material_refs"]![1]!.GetValue<string>()==s["extra_material_refs"]![0]!.GetValue<string>(),"Grafo golden: referencias cruzadas efecto/animación");
 }
}
static void WriteWave(string path,int frames,int frequency=0)
{
 Directory.CreateDirectory(Path.GetDirectoryName(path)!);using var stream=File.Create(path);using var writer=new BinaryWriter(stream,Encoding.ASCII);
 writer.Write(Encoding.ASCII.GetBytes("RIFF"));writer.Write(36+frames*2);writer.Write(Encoding.ASCII.GetBytes("WAVEfmt "));writer.Write(16);writer.Write((short)1);writer.Write((short)1);writer.Write(16000);writer.Write(32000);writer.Write((short)2);writer.Write((short)16);writer.Write(Encoding.ASCII.GetBytes("data"));writer.Write(frames*2);
 for(int i=0;i<frames;i++) writer.Write((short)(frequency==0?0:Math.Sin(i*2*Math.PI*frequency/16000)*10000));
}
static async Task RunFfmpegAsync(IEnumerable<string> arguments)
{
 var start=new ProcessStartInfo("ffmpeg") {UseShellExecute=false,RedirectStandardError=true,RedirectStandardOutput=true};start.ArgumentList.Add("-hide_banner");start.ArgumentList.Add("-loglevel");start.ArgumentList.Add("error");foreach(var a in arguments)start.ArgumentList.Add(a);
 using var p=Process.Start(start)!;var error=p.StandardError.ReadToEndAsync();var output=p.StandardOutput.ReadToEndAsync();await p.WaitForExitAsync();await output;if(p.ExitCode!=0)throw new IOException(await error);await error;
}
sealed class Checks
{
 public List<string> Names {get;}=new();public void Check(bool condition,string name) {if(!condition)throw new InvalidOperationException("FAIL: "+name);Names.Add(name);}
 public void Throws<T>(Action action,string name) where T:Exception {bool caught=false;try{action();}catch(T){caught=true;}Check(caught,name);}
 public async Task ThrowsAsync<T>(Func<Task> action,string name) where T:Exception {bool caught=false;try{await action();}catch(T){caught=true;}Check(caught,name);}
 public async Task ErrorAsync(Func<Task> action,OperationErrorCode code,string name) {try{await action();}catch(CaptionForgeOperationException ex){Check(ex.Code==code,name+" ("+ex.Code+")");return;}throw new InvalidOperationException("FAIL no exception: "+name);}
}
sealed class ClosedGuard : ICapCutProcessGuard {public void EnsureClosed() {}}
sealed class OpenGuard : ICapCutProcessGuard {public void EnsureClosed()=>throw new CaptionForgeOperationException(OperationErrorCode.CapCutOpen,"test process open");}
sealed class DelayedCompletionStore(JsonWorkspaceStore store) : IWorkspaceStore
{
 public TaskCompletionSource Entered {get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
 public TaskCompletionSource Release {get;}=new(TaskCreationOptions.RunContinuationsAsynchronously);
 public Task<RunContext> CreateRunAsync(GenerateCaptionsRequest r,CancellationToken ct=default)=>store.CreateRunAsync(r,ct);
 public Task<ManagedSubtitleSet?> ReadManagedSubtitlesAsync(string p,string t,CancellationToken ct=default)=>store.ReadManagedSubtitlesAsync(p,t,ct);
 public Task SaveGenerationAsync(GenerationResult r,CancellationToken ct=default)=>store.SaveGenerationAsync(r,ct);
 public Task TransitionAsync(RunContext r,RunUpdate u,CancellationToken ct=default)=>store.TransitionAsync(r,u,ct);
 public async Task CompleteAsync(GenerationResult r,SubtitleApplyResult applied,DateTimeOffset at,CancellationToken ct=default)
 {Entered.SetResult();await Release.Task;await store.CompleteAsync(r,applied,at,ct);}
}
sealed class FailCommitter(int failAt) : IFileCommitter
{private int _count;public Task ReplaceAsync(string path,byte[] bytes) {if(++_count==failAt)throw new IOException("injected partial failure");return new AtomicFileCommitter().ReplaceAsync(path,bytes);}}
sealed class BreakRollbackCommitter(string testRoot) : IFileCommitter
{
 private int _count;
 public async Task ReplaceAsync(string path,byte[] bytes)
 {
  if(++_count==1) {await new AtomicFileCommitter().ReplaceAsync(path,bytes);return;}
  // Busca el backup propio del test y lo daña para verificar journal recuperable sin modificar otros proyectos.
  foreach(string backup in Directory.GetFiles(testRoot,"000.bin",SearchOption.AllDirectories))File.WriteAllText(backup,"damaged backup");
  throw new IOException("injected rollback failure");
 }
}
sealed class FixtureAudio : IAudioPreparationService
{
 public Task<PreparedAudio> PrepareAsync(AudioPreparationRequest request,CancellationToken cancellationToken=default)
 {
  string path=Path.Combine(request.Run.RunDirectory,"audio","fixture.wav");int frames=checked((int)Math.Round((decimal)request.RequiredDurationUs*16000/1_000_000,MidpointRounding.AwayFromZero));
  using(var stream=File.Create(path)) using(var w=new BinaryWriter(stream,Encoding.ASCII))
  {w.Write(Encoding.ASCII.GetBytes("RIFF"));w.Write(36+frames*2);w.Write(Encoding.ASCII.GetBytes("WAVEfmt "));w.Write(16);w.Write((short)1);w.Write((short)1);w.Write(16000);w.Write(32000);w.Write((short)2);w.Write((short)16);w.Write(Encoding.ASCII.GetBytes("data"));w.Write(frames*2);w.Write(new byte[frames*2]);}
  return Task.FromResult(new PreparedAudio(request.Segment.Id,path,request.RequiredDurationUs,PcmWaveInfo.Read(path).DurationUs));
 }
}
sealed class FixtureTranscription(string fixtureDirectory) : ITranscriptionService
{
 public bool ChangeFirstWord {get;set;}
 public Task<TranscriptionResult> TranscribeAsync(RunContext run,PreparedAudio audio,TranscriptionOptions options,CancellationToken cancellationToken=default)
 {
  using var data=JsonDocument.Parse(File.ReadAllText(Path.Combine(fixtureDirectory,"whisper_dtw.json")));var phrases=new List<TranscriptionSegment>();int index=0;
  foreach(var e in data.RootElement.GetProperty("transcription").EnumerateArray())
  {
   var offsets=e.GetProperty("offsets");long from=offsets.GetProperty("from").GetInt64(),to=offsets.GetProperty("to").GetInt64();var tokens=new List<WhisperToken>();
   foreach(var token in e.GetProperty("tokens").EnumerateArray())
   {
    string value=token.GetProperty("text").GetString()!;if(index==9 && value==" words")value="words";if(index==14 && value==",")value=".";if(index==14 && value==" math")value=" Math";
    if(index==0 && ChangeFirstWord && value==" This")value=" That";var o=token.GetProperty("offsets");
    tokens.Add(new WhisperToken {Id=token.GetProperty("id").GetInt32(),Text=value,Start=o.GetProperty("from").GetInt64()/10,End=o.GetProperty("to").GetInt64()/10,DtwTimestamp=token.GetProperty("t_dtw").GetInt64()});
   }
   var native=new SegmentData(e.GetProperty("text").GetString()!,TimeSpan.FromMilliseconds(from),TimeSpan.FromMilliseconds(to),0,0,0,0,"en",tokens.ToArray());
   phrases.Add(WhisperTokenNormalizer.Normalize(native,true));index++;
  }
  return Task.FromResult(new TranscriptionResult(audio.SourceSegmentId,options.ModelName,"en",audio.DurationUs,phrases));
 }
}
sealed class Session
{
 public required string Directory {get;init;}
 public required string Draft {get;init;}
 public required string RootDraft {get;init;}
 public required CaptionForge.Core.Models.CapCut.CapCutProject Project {get;init;}
 public required CaptionForge.Application.Models.CapCut.TimelineSnapshot Snapshot {get;set;}
 public required CapCutCatalog Catalog {get;init;}
 public required TemplateAssetPaths Assets {get;init;}
 public required JsonWorkspaceStore Store {get;init;}
 public required FixtureTranscription Transcriber {get;init;}
 public required GoldenV3SubtitleWriter Writer {get;set;}
 public CaptionGenerationService Service => new(new FixtureAudio(),Transcriber,Writer,Store);
 public string[] Files => new[] {Draft,Draft+".bak",RootDraft,RootDraft+".bak"};
 public GenerateCaptionsRequest Request()=>new(Snapshot,new[] {Snapshot.Tracks.Single(t=>t.Segments.Count>0 && t.Type==CaptionForge.Core.Enums.MediaTrackType.Audio).Segments[0].Id},new("medium.en","fixture-model.bin","en",6,8),Store.RootDirectory);
 public Task<GenerationResult> GenerateAsync()=>Service.GenerateAsync(Request());
 public string Status()=>ReadLocal(Path.Combine(Directory,"workspace",Project.Id,"runs",System.IO.Directory.GetDirectories(Path.Combine(Directory,"workspace",Project.Id,"runs")).Select(Path.GetFileName).Last()!,"run.json"))["status"]!.GetValue<string>();
 public void SetWriter(GoldenV3SubtitleWriter writer)=>Writer=writer;
 private static JsonObject ReadLocal(string path)=>JsonNode.Parse(File.ReadAllBytes(path))!.AsObject();
 public static async Task<Session> CreateAsync(string root,string fixtures,string fixture,string? rootFixture)
 {
  string directory=Path.Combine(root,Guid.NewGuid().ToString("N")),projects=Path.Combine(directory,"capcut","projects"),project=Path.Combine(projects,"1003"),tid="EFA8ACC8-F181-4059-96C5-6BC82353A0C6";
  string timeline=Path.Combine(project,"Timelines",tid);System.IO.Directory.CreateDirectory(timeline);
  File.Copy(Path.Combine(fixtures,"draft_meta_info.json"),Path.Combine(project,"draft_meta_info.json"));File.Copy(Path.Combine(fixtures,"timelines_project.json"),Path.Combine(project,"Timelines","project.json"));
  File.Copy(Path.Combine(fixtures,fixture),Path.Combine(timeline,"draft_content.json"));File.Copy(Path.Combine(fixtures,rootFixture ?? fixture),Path.Combine(project,"draft_content.json"));
  File.WriteAllText(Path.Combine(project,"draft_cover.jpg"),"test cover");File.WriteAllText(Path.Combine(timeline,"draft_cover.jpg"),"test cover");
  string cache=Path.Combine(directory,"cache","Cache","effect");string template=Path.Combine(cache,"7535399757947161873","ae92e3cb3480090dfea046d1283495cf"),effect=Path.Combine(cache,"239386920","b7bae96650ebe1f0fbdf8825910dd311"),animation=Path.Combine(cache,"110456508","d62a12a386bf578a8eb03187095d7c7d"),font=Path.Combine(cache,"7517426090072149264","font-hash","BebasNeue-Regular.ttf");
  foreach(string d in new[] {template,effect,animation,Path.GetDirectoryName(font)!}) {System.IO.Directory.CreateDirectory(d);File.WriteAllText(Path.Combine(d,"fixture-resource.txt"),"test visual asset");}File.WriteAllText(font,"test font");
  var assets=CapCutTemplateAssetResolver.Resolve(Path.Combine(directory,"cache"));var catalog=new CapCutCatalog();var p=(await catalog.FindProjectsAsync(projects)).Single();var t=(await catalog.GetTimelinesAsync(p)).Single();
  return new Session {Directory=directory,Draft=t.DraftContentPath,RootDraft=Path.Combine(project,"draft_content.json"),Project=p,Snapshot=await catalog.ReadTimelineAsync(p,t),Catalog=catalog,Assets=assets,Store=new JsonWorkspaceStore(Path.Combine(directory,"workspace")),Transcriber=new(fixtures),Writer=new(assets,new ClosedGuard())};
 }
}
