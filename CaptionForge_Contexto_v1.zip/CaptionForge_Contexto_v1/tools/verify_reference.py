"""Verifica los fixtures; no ejecuta Whisper ni modifica proyectos de CapCut.
Las dos correcciones editoriales son exclusivas del ejemplo QR.
"""
import json
import re
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
REF = BASE / 'references'


def read(name):
    return json.loads((REF / name).read_text(encoding='utf-8-sig'))


def get_captions(draft):
    templates = {m['id']: m for m in draft['materials']['text_templates']}
    texts = {m['id']: m for m in draft['materials']['texts']}
    captions = []
    for track in draft['tracks']:
        if track['type'] != 'text':
            continue
        for seg in track['segments']:
            template = templates[seg['material_id']]
            attachment = template['text_info_resources'][0]
            text = texts[attachment['text_material_id']]
            captions.append({'range': seg['target_timerange'],
                             'text': json.loads(text['content'])['text'],
                             'words': text['words'],
                             'segment': seg, 'template': template,
                             'text_material': text, 'attachment': attachment})
    return captions


def reconstruct(entry, index):
    start_ms, end_ms = entry['offsets']['from'], entry['offsets']['to']
    start_frame = start_ms * 30 // 1000
    duration_frames = (end_ms - start_ms) * 30 // 1000
    start_us = start_frame * 1_000_000 // 30
    end_us = (start_frame + duration_frames) * 1_000_000 // 30
    duration_us = end_us - start_us
    origin_ms = (start_us + 500) // 1000
    duration_ms = (duration_us + 500) // 1000
    words = []
    for token in entry['tokens']:
        raw = token['text']
        if raw.startswith('[_') or not raw.strip():
            continue
        value = raw.strip()
        if raw[0].isspace() or not words:
            words.append([value, token['offsets']['from'], token['offsets']['to']])
        else:
            words[-1][0] += value
            if not re.fullmatch(r'[.,!?;:]+', value):
                words[-1][2] = token['offsets']['to']
    # Correcciones humanas del fixture, no reglas generales del producto.
    if index == 9:
        for i in range(len(words) - 1):
            if words[i][0] == 'code' and words[i + 1][0] == 'words.':
                words[i:i + 2] = [['codewords.', words[i][1], words[i + 1][2]]]
                break
    if index == 14:
        for word in words:
            if word[0] == 'magic,': word[0] = 'magic.'
            if word[0] == 'math.': word[0] = 'Math.'
    for word in words:
        word[1] = min(duration_ms, max(0, word[1] - origin_ms))
        word[2] = min(duration_ms, max(0, word[2] - origin_ms))
    if words:
        words[0][1] = 0
        words[-1][2] = duration_ms
    result = {'text': [], 'start_time': [], 'end_time': []}
    for i, (value, start, end) in enumerate(words):
        if i:
            previous_end = words[i - 1][2]
            result['text'].append(' ')
            result['start_time'].append(previous_end)
            result['end_time'].append(previous_end)
        result['text'].append(value)
        result['start_time'].append(start)
        result['end_time'].append(end)
    return {'range': {'start': start_us, 'duration': duration_us},
            'text': ''.join(result['text']), 'words': result}


def verify():
    golden = read('golden_v3.json')
    captions = get_captions(golden)
    all_ids = {m['id'] for v in golden['materials'].values() if isinstance(v, list)
               for m in v if isinstance(m, dict) and m.get('id')}
    animations = {m['id']: m for m in golden['materials']['material_animations']}
    effects = {m['id']: m for m in golden['materials']['effects']}
    for c in captions:
        seg, attachment, text = c['segment'], c['attachment'], c['text_material']
        words, duration = c['words'], c['range']['duration']
        assert len(words['text']) == len(words['start_time']) == len(words['end_time'])
        assert ''.join(words['text']) == c['text']
        assert json.loads(text['content'])['styles'][0]['range'] == [0, len(c['text'])]
        assert all(0 <= start <= end <= (duration + 500) // 1000
                   for start, end in zip(words['start_time'], words['end_time']))
        assert all(start < end if word != ' ' else start == end
                   for word, start, end in zip(words['text'], words['start_time'], words['end_time']))
        assert attachment['attach_info']['duration'] == duration - 1
        assert all(ref in all_ids for ref in seg['extra_material_refs'] + attachment['extra_material_refs'])
        animation_id, effect_id = seg['extra_material_refs']
        assert animation_id in animations and effect_id in effects
        assert attachment['extra_material_refs'] == [effect_id, animation_id]
        assert animations[animation_id]['animations'][0]['duration'] == duration - 1
    report = {'caption_count': len(captions),
              'lexical_word_count': sum(sum(w != ' ' for w in c['words']['text']) for c in captions),
              'golden_structural_validation': 'passed', 'comparisons': {}}
    for filename in ['whisper_dtw.json', 'whisper_regular.json']:
        transcriptions = read(filename)['transcription']
        assert len(transcriptions) == len(captions)
        rebuilt = [reconstruct(entry, i) for i, entry in enumerate(transcriptions)]
        comparison = {name + '_matches': sum(r[name] == c[name] for r, c in zip(rebuilt, captions))
                      for name in ['range', 'text', 'words']}
        comparison['word_mismatch_caption_numbers'] = [i + 1 for i, (r, c) in enumerate(zip(rebuilt, captions))
                                                      if r['words'] != c['words']]
        report['comparisons'][filename] = comparison
    assert report['caption_count'] == 15
    assert report['lexical_word_count'] == 91
    assert report['comparisons']['whisper_dtw.json']['words_matches'] == 15
    assert report['comparisons']['whisper_dtw.json']['range_matches'] == 15
    assert report['comparisons']['whisper_dtw.json']['text_matches'] == 15
    assert report['comparisons']['whisper_regular.json']['words_matches'] == 13
    meta, registry, root = read('draft_meta_info.json'), read('timelines_project.json'), read('root_draft_content.json')
    assert meta['draft_id'] == '2A30AAE9-2228-48ab-BA00-AF0598C88C3B'
    assert registry['id'] == '3A81E819-70C3-4b5c-8DB8-4D07897271C9'
    assert registry['main_timeline_id'] == root['id'] == 'EFA8ACC8-F181-4059-96C5-6BC82353A0C6'
    assert len(registry['timelines']) == 1
    assert not registry['timelines'][0]['is_marked_delete']
    report['project_identity_validation'] = 'passed'
    report['limitations'] = ['No se ejecutó Whisper.net, FFmpeg ni CapCut.',
                            'La reconstrucción verifica exclusivamente los fixtures QR incluidos.',
                            'No se recuperó el código original del generador v3.']
    return report


if __name__ == '__main__':
    print(json.dumps(verify(), ensure_ascii=False, indent=2))
