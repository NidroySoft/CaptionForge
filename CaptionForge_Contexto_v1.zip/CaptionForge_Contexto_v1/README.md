# CaptionForge — paquete de continuidad v1

1. Lee `CaptionForge_Blueprint_v1.md`.
2. Usa `references/golden_v3.json` como referencia definitiva del estilo; los snapshots manuales no la sustituyen.
3. Para retomar en otro chat, entrega este ZIP completo o el blueprint junto con las referencias pertinentes.
4. Opcional: con Python 3.9+ ejecuta `python tools/verify_reference.py`. Solo comprueba los fixtures incluidos.

Este paquete documenta el producto y la evidencia. No es una aplicación compilada ni un instalador. Los JSON originales no se modificaron. La imagen es una maqueta inicial: su proporción panorámica de portadas fue corregida por el criterio multiformato del blueprint.

No contiene audio original, modelos, FFmpeg, runtimes de Whisper ni fuentes/efectos de CapCut. Esos recursos se necesitan para las pruebas de ejecución, pero no para recuperar el contexto de planificación.

El manifiesto de fuentes conserva los SHA-256 de las copias originales. El informe de validación distingue la comprobación de fixtures de las pruebas de ejecución pendientes.
